// ============================================================
//  秋雨創新股份有限公司｜內部訓練簽到系統｜Google Apps Script
//  【部署方式】
//  1. 從 Google 試算表開啟：擴充功能 → Apps Script
//  2. 貼上此程式碼（取代原本內容）
//  3. 部署 → 新增部署 → 類型：網路應用程式
//     - 執行身分：我
//     - 存取對象：所有人（包括匿名）
//  4. 複製「網路應用程式 URL」貼到 teacher.html
// ============================================================

const SHEET_NAME = '簽到紀錄';

function getSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);
  return sheet;
}

function doGet(e) {
  const params = e.parameter;
  const sheet = getSheet();

  if (params.action === 'getRecords') {
    const sid = params.sessionId;
    const data = sheet.getDataRange().getValues();
    const records = [];
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][0]) === String(sid)) {
        records.push({
          sessionId:  data[i][0],
          no:         data[i][1],
          empId:      data[i][2],
          name:       data[i][3],
          status:     data[i][4],
          evalMethod: data[i][5],
          evalResult: data[i][6],
          note:       data[i][7],
          time:       data[i][8],
          date:       data[i][9]
        });
      }
    }
    return out({ ok: true, records });
  }

  return out({ ok: false, error: 'unknown action' });
}

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const sheet = getSheet();

    // 建立標題列（只在空表時建立）
    if (sheet.getLastRow() === 0) {
      const headers = ['SessionID','序號','員工編號','姓名','出席狀態',
        '考核方式','考核結果','備註','簽到時間','簽到日期',
        '課程名稱','課程日期','課程時間','授課講師','課程地點','課程編號'];
      sheet.appendRow(headers);
      sheet.getRange(1,1,1,headers.length)
        .setFontWeight('bold')
        .setBackground('#1C4532')
        .setFontColor('#ffffff');
    }

    if (data.action === 'init') {
      return out({ ok: true, sessionId: data.sessionId });
    }

    if (data.action === 'checkin') {
      const sid = data.sessionId;
      const all = sheet.getDataRange().getValues();
      let count = 0;
      for (let i = 1; i < all.length; i++) {
        if (String(all[i][0]) === String(sid)) count++;
      }
      sheet.appendRow([
        sid, count + 1,
        data.empId     || '',
        data.name      || '',
        data.status === 'late' ? '遲到' : '出席',
        data.evalMethod|| '',
        data.evalResult|| '',
        data.note      || '',
        data.time      || '',
        data.date      || '',
        data.course    || '',
        data.courseDate|| '',
        data.courseTime|| '',
        data.teacher   || '',
        data.location  || '',
        data.code      || ''
      ]);
      return out({ ok: true, no: count + 1 });
    }

    return out({ ok: false, error: 'unknown action' });

  } catch (err) {
    return out({ ok: false, error: err.toString() });
  }
}

function out(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

// 【測試用】在編輯器直接執行此函式驗證邏輯（不要直接執行 doPost）
function testCheckin() {
  const fake = {
    postData: {
      contents: JSON.stringify({
        action: 'checkin',
        sessionId: 'test_001',
        name: '測試學員',
        empId: 'E001',
        status: 'present',
        evalMethod: '',
        evalResult: '',
        note: '',
        time: '09:05',
        date: '2026-03-15',
        course: '測試課程',
        courseDate: '2026-03-15',
        courseTime: '09:00–12:00',
        teacher: '測試講師',
        location: '台北大會議室',
        code: 'TEST-001'
      })
    }
  };
  Logger.log(doPost(fake).getContent());
}
